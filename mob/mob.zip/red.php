$isi = "#0099cb";
echo '<text fill="'.$isi.'" font-size="15" font-family="Arial" font-weight= "bold" x="449" y="41">'.$n.'</text>';


$isi = "#21ae41";
echo '<text fill="' . $isi . '" font-size="15" font-family="Arial" font-weight= "bold" x="449" y="41">' . $n . '</text>';

$isi = "#eef200";
echo '<text fill="' . $isi . '" font-size="15" font-family="Arial" font-weight= "bold" x="449" y="41">' . $n . '</text>';

$isi = "#ff4441";
echo '<text fill="' . $isi . '" font-size="15" font-family="Arial" font-weight= "bold" x="449" y="41">' . $n . '</text>';


