<?php

echo "t";
