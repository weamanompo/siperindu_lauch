<?php

// $koneksi = mysqli_connect("localhost", "root","","siperindu_upload");
$koneksi = mysqli_connect("localhost", "root","","siperindu_ind");
